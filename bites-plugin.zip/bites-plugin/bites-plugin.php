<?php 

/** 
 * 
 * @package BitesPlugin
 * 
*/
/*

Plugin Name: Bites Plugin
Plugin URL: https://bernermedia.fi
Description: Bites Burgersille suunniteltu WordPress plugin
Version: 1.0.0
Author: Justus Berner I Berner Media
Author URL: www.bernermedia.fi 
License: GPLv2 or later 
Text Domain: bites-plugin
*/